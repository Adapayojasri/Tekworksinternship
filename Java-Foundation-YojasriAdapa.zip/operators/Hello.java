class Hello
  {
    public static void main(String args[])
    {
      System.out.println("hello");
    }
  }